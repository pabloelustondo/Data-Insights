from __future__ import print_function
from pymongo import MongoClient
from bson.code import Code

import boto3
import json

from urllib import quote_plus

print('Loading function')

s3 = boto3.resource('s3')

def lambda_handler(event, context):
    
    #Need to call another func to get all result as paras
    _connectionString = '34.206.170.83:5494'
    _userName = 'sotiadmin'
    _password = quote_plus('eXtremely$tr0ngp@$$w0rd')
    _dbName = 'test'
    _collection = 'sessions'
    print (_password)
    #qry = qry.replace('$[vehicleId]', event['vehicleId'])
    res = executeQuery (_connectionString, _userName, _password, _dbName, _collection)
    return (res)

def executeQuery (_connectionString, _userName, _password, _dbName, _collection):
    conn = MongoClient("mongodb://" + _userName + ":" + _password + "@" +  _connectionString)
    db = conn[_dbName]
    
    _mapFunction = Code(s3.Object('da-s3-bucket', 'MongoQueries/mapFunction.js').get()['Body'].read())
    _reduceFunction = Code(s3.Object('da-s3-bucket', 'MongoQueries/reduceFunction.js').get()['Body'].read())
    
    #finalizeFunction = Code(s3.Object('da-s3-bucket', 'MongoQueries/finalizeFunction.js').get()['Body'].read())
    
    #result = db.command({
    #    'mapReduce': _collection,
    #    'map': mapFunction,
    #    'reduce': reduceFunction,
    #    'finalize': finalizeFunction,
    #    'out': 'session_stat'
    #})
    
    result = db[_collection].inline_map_reduce(_mapFunction, _reduceFunction)
    
   
    return(result)