import {Route, Get, Post, Delete, Patch, Example} from 'tsoa';
import {User, UserCreateRequest, UserUpdateRequest} from '../models/user';
// import * as https from 'https';
const config = require('../../appconfig.json');
import * as querystring from 'querystring';

import * as rp from 'request-promise';
@Route('Users')
export class UsersController {

    /** Get the current user */
    @Get('Current')
    @Example<User>({
        createdAt: new Date(),
        email: 'test@test.com',
        id: 1
    })
    public async Current(): Promise<User> {
        return {
            createdAt: new Date(),
            email: 'test',
            id: 666
        };
    }

    /** Get user by ID */
    @Get('{dataSetName}')
    public async Get(dataSetName: string, dateFrom: string, dateTo: string): Promise<User> {

        const xqs = {dateFrom: dateFrom, dateTo: dateTo };
        const xurl = 'https://' + config['aws-hostname'] + config['aws-path'];

        const options: rp.OptionsWithUrl = {
            headers: {
                'x-api-key': config['aws-x-api-key']
            },
            json: true,
            method: 'GET',
            qs: xqs,
            url: xurl
        };

        let p = await rp(options);

        const user: User = {
            createdAt: new Date(),
            email: 'kakak',
            id: 0,
            data: p
        };



        return user;
    }

    /** 
     * Create a user 
     * @param request This is a user creation request description 
     */
    @Post()
    public async Create(request: UserCreateRequest, optionalString?: string): Promise<User> {
        return {
            createdAt: new Date(),
            email: request.email,
            id: 666
        };
    }

    /** Delete a user by ID */
    @Delete('{userId}')
    public async Delete(userId: number): Promise<void> {
        return Promise.resolve();
    }

    /** Update a user */
    @Patch()
    public async Update(request: UserUpdateRequest): Promise<User> {
        return {
            createdAt: request.createdAt,
            email: request.email,
            id: 1337
        };
    }
}
