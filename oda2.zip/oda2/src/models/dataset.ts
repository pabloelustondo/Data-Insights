// Pablo Elustondo November 2016

export interface DataSetParameter {
    key: string;
    value: string;
}

export interface DataSet {
    // a DataSet represents a response from the Data Analytics Dashboard.
    // the property 'data' represents the actual data which is a list of objects most likely of the same type.
    // We may introduce a type for that data.
    // other parameters are mostly metadata that explains where this data come from and when was created.
    // yes, the datasource and the parameters are somehow redundant because the caller knows that informatio,
    // and we may remove these two parameters later. For now is a very convenient way to debug and understand where
    // the data comes from in other modules.

    datasource: string; // i.e: 2vf2f8xp27.execute-api.us-east-1.amazonaws.com
    datasetpath: string; // i.e: /test/function_one
    parameters: DataSetParameter[]; // i.e: {dateFrom: '2016-08-16', dateTo: '2016-08-18'};
    status: string; // will fix this later... for now is just 'ok' or 'error'...
    createdAt: Date;
    data: Object[];   // i.e. normally a set of rows representing a variable in a multidimensional space.
}

