export interface User {
    id: number;
    email: string;
    createdAt: Date;
    data?: string[];
}

export interface UserCreateRequest {
    email: string;
}

export interface UserUpdateRequest {
    createdAt?: Date;
    email: string;
}
